import torch
import os
from torch import nn
from torch.nn import functional as F
from torch.autograd import Variable
import matplotlib.pyplot as plt
from torchvision.datasets import ImageFolder
import torch.optim as optim
import torch.utils.data
from PIL import Image
import torchvision.transforms as transforms


class Model1(nn.Module):
    # def __init__(self):
    #     super(Model1, self).__init__()
    #     self.linear = nn.Linear(1, 1)
    #     nn.Linear(in_features=30, out_features=16, bias=True),
    #     #         nn.ReLU(),
    #     #         # nn.Linear(in_features=16, out_features=32, bias=True),
    #     #         # nn.ReLU(),
    #     #         nn.Linear(in_features=16, out_features=n_classes, bias=True),
    #     # 为了简单，构建一个全连接，没有隐藏层
    #     # 输入是一维，输出也是一维
    #
    # def forward(self, inputs):
    #     logits = self.linear(inputs)
    #     return logits
    def __init__(self):
        super(Model1, self).__init__()
        # self.features = nn.Sequential(
        #     nn.Conv2d(in_channels=30, out_channels=6, kernel_size=5, stride=1, padding=0, bias=True),
        #     nn.Tanh(),
        #     # nn.MaxPool2d(kernel_size=2, stride=2),
        #     nn.Conv2d(in_channels=6, out_channels=16, kernel_size=5, stride=1, padding=0, bias=True),
        #     nn.Tanh(),
        #     # nn.MaxPool2d(kernel_size=2, stride=2),
        # )
        # self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.classifier = nn.Sequential(
            nn.Linear(in_features=30, out_features=16, bias=True),
            nn.ReLU(),
            nn.Linear(in_features=16, out_features=1, bias=True),
            # nn.ReLU(),
            # nn.Linear(in_features=8, out_features=1, bias=True),
            # nn.Sigmoid()
        )

    def forward(self, x):
        # x = self.features(x)
        # x = torch.flatten(x, start_dim=1)
        # x=self.avg_pool(x)
        x = self.classifier(x)
        return x