import torch
import torch.nn as nn
# from models.Attention import *
from torchsummary import summary


class SELayer(nn.Module):
    def __init__(self, channel, reduction=16):
        super(SELayer, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(channel // reduction, channel, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        # b,c,h.w
        b, c, _, _ = x.size()  # batch \channel\ high\ weight
        # b,c,1,1----> b,c
        y = self.avg_pool(x).view(b, c)  # 调整维度、去掉最后两个维度
        # b,c- ----> b,c/16 ---- >b,c ----> b,c,1,1
        y = self.fc(y).view(b, c, 1, 1)  # 添加上h,w维度
        return x * y.expand_as(x)  # 来扩展张量中某维数据的尺寸，将输入tensor的维度扩展为与指定tensor相同的size


class Model1(nn.Module):
    def __init__(self):
        super(Model1, self).__init__()
        # 30*9*9
        self.conv1 = nn.Conv2d(in_channels=30, out_channels=64, kernel_size=3, stride=1, padding=1, bias=True)
        # 64*9*9
        self.bn1 = nn.BatchNorm2d(64)
        self.relu1 = nn.ReLU(inplace=True)
        # SE Block
        # self.layer1 = self._make_layer(64)
        self.layer1 = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)  # 64*5*5
        self.conv2 = nn.Conv2d(in_channels=64, out_channels=128, kernel_size=3, stride=1, padding=1,
                               bias=True)  # 128*5*5
        self.bn2 = nn.BatchNorm2d(128)
        self.relu2 = nn.ReLU(inplace=True)
        # SE Block
        # self.layer2 = self._make_layer(128)  # 128*3*3
        self.layer2 = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)  # 128*3*3

        # self.conv3 = nn.Conv2d(in_channels=128, out_channels=256, kernel_size=3, stride=1, padding=1, bias=True)  # 256*3*3
        # self.bn3 = nn.BatchNorm2d(256)
        # self.relu3 = nn.ReLU(inplace=True)
        # self.layer3 = nn.MaxPool2d(kernel_size=3, stride=2, padding=0)  # 256*1*1

        self.classifier = nn.Sequential(
            nn.Linear(in_features=1152, out_features=256, bias=True),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.5),
            nn.Linear(in_features=256, out_features=32, bias=True),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.5),
            nn.Linear(in_features=32, out_features=1, bias=True),
            # nn.Softmax(dim=-1)
        )

    def _make_layer(self, channel):
        # 定义一个空列表，用来装convx_x的网络结构
        layers = [SELayer(channel)]
        # 首先要把第一个残差结构加进去，因为第一个残差结构涉及到虚线残差结构
        return nn.Sequential(*layers)

    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu1(x)
        x = self.layer1(x)
        x = self.conv2(x)
        x = self.bn2(x)
        x = self.relu2(x)
        x = self.layer2(x)
        # x = self.conv3(x)
        # x = self.bn3(x)
        # x = self.relu3(x)
        # x = self.layer3(x)
        x = torch.flatten(x, start_dim=1)
        x = self.classifier(x)
        return x
