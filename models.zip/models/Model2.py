import torch
import torch.nn as nn


class Model2(nn.Module):
    def __init__(self):
        super(Model2, self).__init__()
        # 30*7*7
        self.conv1 = nn.Conv2d(in_channels=30, out_channels=64, kernel_size=3, stride=1, padding=0, bias=True)
        # 64*5*5
        self.bn1 = nn.BatchNorm2d(64)
        self.relu1 = nn.ReLU(inplace=True)
        self.maxpool1 = nn.MaxPool2d(kernel_size=3, stride=2, padding=0)
        # # 64*3*3
        # self.conv2 = nn.Conv2d(in_channels=64, out_channels=128, kernel_size=3, stride=1, padding=1, bias=True)
        # # 128*3*3
        # self.bn2 = nn.BatchNorm2d(128)
        # self.relu2 = nn.ReLU(inplace=True)
        # self.maxpool2 = nn.MaxPool2d(kernel_size=2, stride=2, padding=0)

        self.classifier = nn.Sequential(
            nn.Linear(in_features=256, out_features=512, bias=True),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.5),
            nn.Linear(in_features=512, out_features=256, bias=True),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.5),
            nn.Linear(in_features=256, out_features=1, bias=True),
            # nn.Softmax(dim=-1)
        )

    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu1(x)
        x = self.maxpool1(x)
        # x = self.conv2(x)
        # x = self.bn2(x)
        # x = self.relu2(x)
        # x = self.maxpool2(x)
        x = torch.flatten(x, start_dim=1)
        x = self.classifier(x)
        return x
