import torch
import torch.nn as nn
from torchsummary import summary
from models.Attention import *


class DilatedBlock(nn.Module):
    def __init__(self, in_ch, out_ch):
        super(DilatedBlock, self).__init__()
        self.layer1 = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, (3, 3), padding=(1, 1), dilation=(1, 1)),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )
        self.layer2 = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, (3, 3), padding=(2, 2), dilation=(2, 2)),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )
        self.layer3 = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, (3, 3), padding=(3, 3), dilation=(3, 3)),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )
        self.conv = nn.Conv2d(out_ch * 3, out_ch, (3, 3), padding=(1, 1), dilation=(1, 1))
        self.bn = nn.BatchNorm2d(out_ch)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        o1 = self.layer1(x)
        o2 = self.layer2(x)
        o3 = self.layer3(x)
        o = torch.cat((o1, o2, o3), dim=1)
        o = self.relu(self.bn(x + self.conv(o)))
        return o


class Model12(nn.Module):
    def __init__(self, num_channels):
        super(Model12, self).__init__()
        self.conv1 = nn.Conv2d(in_channels=30, out_channels=64, kernel_size=3, stride=1, padding=1, bias=True)
        # 64*9*9
        self.relu1 = nn.ReLU(inplace=True)
        # dilated
        self.dilated = nn.Sequential(
            *[DilatedBlock(64, 64) for i in range(1)]
        )
        # CBAM
        self.layer1 = self._make_layer(64)  # 128*3*3

        self.classifier = nn.Sequential(
            nn.Linear(in_features=5184, out_features=256, bias=True),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.5),
            nn.Linear(in_features=256, out_features=32, bias=True),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.5),
            nn.Linear(in_features=32, out_features=1, bias=True),
            # nn.Softmax(dim=-1)
        )

    def _make_layer(self, channel):
        # 定义一个空列表，用来装convx_x的网络结构
        layers = [ECA(channel)]
        # 首先要把第一个残差结构加进去，因为第一个残差结构涉及到虚线残差结构
        return nn.Sequential(*layers)

    def forward(self, x):
        x = self.conv1(x)
        x = self.relu1(x)
        x = self.dilated(x)
        x = self.layer1(x)
        x = torch.flatten(x, start_dim=1)
        x = self.classifier(x)


# """print layers and params of network"""
# if __name__ == '__main__':
#     device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
#     model = Model12(num_channels=1).to(device)
#     summary(model, (30, 9, 9))
