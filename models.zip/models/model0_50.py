import torch
import torch.nn as nn
from models.Attention import *
from torchsummary import summary


class DilatedBlock(nn.Module):
    def __init__(self, in_ch, out_ch):
        super(DilatedBlock, self).__init__()
        self.layer1 = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, (3, 3), padding=(1, 1), dilation=(1, 1)),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )
        self.layer2 = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, (3, 3), padding=(2, 2), dilation=(2, 2)),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )
        self.layer3 = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, (3, 3), padding=(3, 3), dilation=(3, 3)),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )
        self.conv = nn.Conv2d(out_ch * 3, out_ch, (3, 3), padding=(1, 1), dilation=(1, 1))
        self.bn = nn.BatchNorm2d(out_ch)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        o1 = self.layer1(x)
        o2 = self.layer2(x)
        o3 = self.layer3(x)
        o = torch.cat((o1, o2, o3), dim=1)
        o = self.relu(self.bn(x + self.conv(o)))
        return o


class Model1(nn.Module):
    """
    SELayer+one times dilated
    双输入（孪生网络）
    """

    def __init__(self):
        super(Model1, self).__init__()
        # 对特征进行学习
        # 30*9*9
        self.conv1 = nn.Conv2d(in_channels=30, out_channels=64, kernel_size=3, stride=1, padding=1, bias=True)
        # 64*9*9
        self.bn1 = nn.BatchNorm2d(64)
        self.relu1 = nn.ReLU(inplace=True)
        self.dilated1 = nn.Sequential(*[DilatedBlock(64, 64) for i in range(1)])
        self.maxpool1 = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)  # 64*7*7
        self.conv2 = nn.Conv2d(in_channels=64, out_channels=128, kernel_size=3, stride=1, padding=1,
                               bias=True)  # 128*5*5
        self.bn2 = nn.BatchNorm2d(128)
        self.relu2 = nn.ReLU(inplace=True)
        self.dilated2 = nn.Sequential(*[DilatedBlock(128, 128) for i in range(1)])
        self.maxpool2 = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)  # 128*3*3
        # ECA
        self.layer3 = self._make_layer(128)  # 128*3*3
        # 对浅层SOC含量分布进行学习
        self.conv3 = nn.Conv2d(in_channels=1, out_channels=64, kernel_size=3, stride=1, padding=1, bias=True)  # 64*9*9
        self.dilated3 = nn.Sequential(*[DilatedBlock(64, 64)])
        self.conv4 = nn.Conv2d(in_channels=64, out_channels=128, kernel_size=3, stride=1, padding=0,
                               bias=True)  # 128*7*7
        self.maxpool3 = nn.MaxPool2d(kernel_size=3, stride=2)  # 128*3*3
        # self.dilated3 = nn.Sequential(*[DilatedBlock(64, 64) for i in range(8)])
        # 全连接层回归
        self.classifier = nn.Sequential(
            nn.Linear(in_features=2304, out_features=256, bias=True),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.5),
            nn.Linear(in_features=256, out_features=32, bias=True),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.5),
            nn.Linear(in_features=32, out_features=1, bias=True),
            # nn.Softmax(dim=-1)
        )

    def _make_layer(self, channel):
        # 定义一个空列表，用来装convx_x的网络结构
        layers = [SELayer(channel)]
        # 首先要把第一个残差结构加进去，因为第一个残差结构涉及到虚线残差结构
        return nn.Sequential(*layers)

    def forward(self, input1, input2):
        x1 = self.conv1(input1)
        x1 = self.bn1(x1)
        x1 = self.relu1(x1)
        x1 = self.dilated1(x1)
        x1 = self.maxpool1(x1)
        x1 = self.conv2(x1)
        x1 = self.bn2(x1)
        x1 = self.relu2(x1)
        x1 = self.dilated2(x1)
        x1 = self.maxpool2(x1)
        x1 = self.layer3(x1)  # size 128*3*3
        # shallower SOC feature extraction wish output size 128*3*3
        x2 = self.conv3(input2)
        x2 = self.dilated3(x2)
        x2 = self.conv4(x2)
        x2 = self.maxpool3(x2)
        x = torch.cat([x1, x2], dim=1)
        # print('x1', x1.shape)
        # print('x2', x2.shape)
        # print('x', x.shape)
        x = torch.flatten(x, start_dim=1)
        # print('x', x.shape)
        x = self.classifier(x)
        # print('x', x.shape)
        return x


class Model1new(nn.Module):
    """
    SELayer+one times dilated
    双输入（孪生网络）
    """

    def __init__(self):
        super(Model1new, self).__init__()
        # 对特征进行学习
        # 30*9*9
        self.conv1 = nn.Conv2d(in_channels=30, out_channels=64, kernel_size=3, stride=1, padding=1, bias=True)
        # 64*9*9
        self.bn1 = nn.BatchNorm2d(64)
        self.relu1 = nn.ReLU(inplace=True)
        self.dilated1 = nn.Sequential(*[DilatedBlock(64, 64) for i in range(1)])
        self.maxpool1 = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)  # 64*7*7
        self.conv2 = nn.Conv2d(in_channels=64, out_channels=128, kernel_size=3, stride=1, padding=1,
                               bias=True)  # 128*5*5
        self.bn2 = nn.BatchNorm2d(128)
        self.relu2 = nn.ReLU(inplace=True)
        self.dilated2 = nn.Sequential(*[DilatedBlock(128, 128) for i in range(1)])
        self.maxpool2 = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)  # 128*3*3
        # ECA
        self.layer3 = self._make_layer(128)  # 128*3*3
        # 对浅层SOC含量分布进行学习
        self.conv3 = nn.Conv2d(in_channels=1, out_channels=64, kernel_size=3, stride=1, padding=1, bias=True)  # 64*9*9
        self.bn3 = nn.BatchNorm2d(64)
        self.relu3 = nn.ReLU(inplace=True)
        self.dilated3 = nn.Sequential(*[DilatedBlock(64, 64)])
        self.conv4 = nn.Conv2d(in_channels=64, out_channels=128, kernel_size=3, stride=1, padding=0,
                               bias=True)  # 128*7*7
        self.bn4 = nn.BatchNorm2d(128)
        self.relu4 = nn.ReLU(inplace=True)
        self.maxpool3 = nn.MaxPool2d(kernel_size=3, stride=2)  # 128*3*3
        # self.dilated3 = nn.Sequential(*[DilatedBlock(64, 64) for i in range(8)])
        # 全连接层回归
        self.classifier = nn.Sequential(
            nn.Linear(in_features=2304, out_features=256, bias=True),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.5),
            nn.Linear(in_features=256, out_features=32, bias=True),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.5),
            nn.Linear(in_features=32, out_features=1, bias=True),
            # nn.Softmax(dim=-1)
        )

    def _make_layer(self, channel):
        # 定义一个空列表，用来装convx_x的网络结构
        layers = [SELayer(channel)]
        # 首先要把第一个残差结构加进去，因为第一个残差结构涉及到虚线残差结构
        return nn.Sequential(*layers)

    def forward(self, input1, input2):
        x1 = self.conv1(input1)
        x1 = self.bn1(x1)
        x1 = self.relu1(x1)
        x1 = self.dilated1(x1)
        x1 = self.maxpool1(x1)
        x1 = self.conv2(x1)
        x1 = self.bn2(x1)
        x1 = self.relu2(x1)
        x1 = self.dilated2(x1)
        x1 = self.maxpool2(x1)
        x1 = self.layer3(x1)  # size 128*3*3
        # shallower SOC feature extraction wish output size 128*3*3
        x2 = self.conv3(input2)
        x2 = self.bn3(x2)
        x2 = self.relu3(x2)
        x2 = self.dilated3(x2)
        x2 = self.conv4(x2)
        x2 = self.bn4(x2)
        x2 = self.relu4(x2)
        x2 = self.maxpool3(x2)
        x = torch.cat([x1, x2], dim=1)
        # print('x1', x1.shape)
        # print('x2', x2.shape)
        # print('x', x.shape)
        x = torch.flatten(x, start_dim=1)
        # print('x', x.shape)
        x = self.classifier(x)
        # print('x', x.shape)
        return x


class Model2(nn.Module):
    """
    SELayer+three times dilated
    双输入（孪生网络）
    """

    def __init__(self):
        super(Model2, self).__init__()
        # 对特征进行学习
        # 30*9*9
        self.conv1 = nn.Conv2d(in_channels=30, out_channels=64, kernel_size=3, stride=1, padding=1, bias=True)
        # 64*9*9
        self.bn1 = nn.BatchNorm2d(64)
        self.relu1 = nn.ReLU(inplace=True)
        self.dilated1 = nn.Sequential(*[DilatedBlock(64, 64) for i in range(1)])
        self.maxpool1 = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)  # 64*7*7
        self.conv2 = nn.Conv2d(in_channels=64, out_channels=128, kernel_size=3, stride=1, padding=1,
                               bias=True)  # 128*5*5
        self.bn2 = nn.BatchNorm2d(128)
        self.relu2 = nn.ReLU(inplace=True)
        self.dilated2 = nn.Sequential(*[DilatedBlock(128, 128) for i in range(1)])
        self.maxpool2 = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)  # 128*3*3
        # ECA
        self.layer3 = self._make_layer(128)  # 128*3*3
        # 对浅层SOC含量分布进行学习
        self.conv3 = nn.Conv2d(in_channels=1, out_channels=64, kernel_size=3, stride=1, padding=1, bias=True)  # 64*9*9
        # self.dilated3 = nn.Sequential(*[DilatedBlock(64, 64)])
        self.dilated3 = nn.Sequential(*[DilatedBlock(64, 64) for i in range(3)])
        self.conv4 = nn.Conv2d(in_channels=64, out_channels=128, kernel_size=3, stride=1, padding=0,
                               bias=True)  # 128*7*7
        self.maxpool3 = nn.MaxPool2d(kernel_size=3, stride=2)  # 128*3*3

        # 全连接层回归
        self.classifier = nn.Sequential(
            nn.Linear(in_features=2304, out_features=256, bias=True),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.5),
            nn.Linear(in_features=256, out_features=32, bias=True),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.5),
            nn.Linear(in_features=32, out_features=1, bias=True),
            # nn.Softmax(dim=-1)
        )

    def _make_layer(self, channel):
        # 定义一个空列表，用来装convx_x的网络结构
        layers = [SELayer(channel)]
        # 首先要把第一个残差结构加进去，因为第一个残差结构涉及到虚线残差结构
        return nn.Sequential(*layers)

    def forward(self, input1, input2):
        x1 = self.conv1(input1)
        x1 = self.bn1(x1)
        x1 = self.relu1(x1)
        x1 = self.dilated1(x1)
        x1 = self.maxpool1(x1)
        x1 = self.conv2(x1)
        x1 = self.bn2(x1)
        x1 = self.relu2(x1)
        x1 = self.dilated2(x1)
        x1 = self.maxpool2(x1)
        x1 = self.layer3(x1)  # size 128*3*3
        # shallower SOC feature extraction wish output size 128*3*3
        x2 = self.conv3(input2)
        x2 = self.dilated3(x2)
        x2 = self.conv4(x2)
        x2 = self.maxpool3(x2)
        x = torch.cat([x1, x2], dim=1)
        # print('x1', x1.shape)
        # print('x2', x2.shape)
        # print('x', x.shape)
        x = torch.flatten(x, start_dim=1)
        # print('x', x.shape)
        x = self.classifier(x)
        # print('x', x.shape)
        return x


class Model3(nn.Module):
    """
    ECA+one time dilated
    双输入（孪生网络）
    """

    def __init__(self):
        super(Model3, self).__init__()
        # 对特征进行学习
        # 30*9*9
        self.conv1 = nn.Conv2d(in_channels=30, out_channels=64, kernel_size=3, stride=1, padding=1, bias=True)
        # 64*9*9
        self.bn1 = nn.BatchNorm2d(64)
        self.relu1 = nn.ReLU(inplace=True)
        self.dilated1 = nn.Sequential(*[DilatedBlock(64, 64) for i in range(1)])
        self.maxpool1 = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)  # 64*7*7
        self.conv2 = nn.Conv2d(in_channels=64, out_channels=128, kernel_size=3, stride=1, padding=1,
                               bias=True)  # 128*5*5
        self.bn2 = nn.BatchNorm2d(128)
        self.relu2 = nn.ReLU(inplace=True)
        self.dilated2 = nn.Sequential(*[DilatedBlock(128, 128) for i in range(1)])
        self.maxpool2 = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)  # 128*3*3
        # ECA
        self.layer3 = self._make_layer(128)  # 128*3*3
        # 对浅层SOC含量分布进行学习
        self.conv3 = nn.Conv2d(in_channels=1, out_channels=64, kernel_size=3, stride=1, padding=1, bias=True)  # 64*9*9
        self.dilated3 = nn.Sequential(*[DilatedBlock(64, 64)])
        # self.dilated3 = nn.Sequential(*[DilatedBlock(64, 64) for i in range(3)])
        self.conv4 = nn.Conv2d(in_channels=64, out_channels=128, kernel_size=3, stride=1, padding=0,
                               bias=True)  # 128*7*7
        self.maxpool3 = nn.MaxPool2d(kernel_size=3, stride=2)  # 128*3*3

        # 全连接层回归
        self.classifier = nn.Sequential(
            nn.Linear(in_features=2304, out_features=256, bias=True),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.5),
            nn.Linear(in_features=256, out_features=32, bias=True),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.5),
            nn.Linear(in_features=32, out_features=1, bias=True),
            # nn.Softmax(dim=-1)
        )

    def _make_layer(self, channel):
        # 定义一个空列表，用来装convx_x的网络结构
        layers = [ECA(channel)]
        # 首先要把第一个残差结构加进去，因为第一个残差结构涉及到虚线残差结构
        return nn.Sequential(*layers)

    def forward(self, input1, input2):
        x1 = self.conv1(input1)
        x1 = self.bn1(x1)
        x1 = self.relu1(x1)
        x1 = self.dilated1(x1)
        x1 = self.maxpool1(x1)
        x1 = self.conv2(x1)
        x1 = self.bn2(x1)
        x1 = self.relu2(x1)
        x1 = self.dilated2(x1)
        x1 = self.maxpool2(x1)
        x1 = self.layer3(x1)  # size 128*3*3
        # shallower SOC feature extraction wish output size 128*3*3
        x2 = self.conv3(input2)
        x2 = self.dilated3(x2)
        x2 = self.conv4(x2)
        x2 = self.maxpool3(x2)
        x = torch.cat([x1, x2], dim=1)
        # print('x1', x1.shape)
        # print('x2', x2.shape)
        # print('x', x.shape)
        x = torch.flatten(x, start_dim=1)
        # print('x', x.shape)
        x = self.classifier(x)
        # print('x', x.shape)
        return x


class Model4(nn.Module):
    """
    ECA+three times dilated
    双输入（孪生网络）
    """

    def __init__(self):
        super(Model4, self).__init__()
        # 对特征进行学习
        # 30*9*9
        self.conv1 = nn.Conv2d(in_channels=30, out_channels=64, kernel_size=3, stride=1, padding=1, bias=True)
        # 64*9*9
        self.bn1 = nn.BatchNorm2d(64)
        self.relu1 = nn.ReLU(inplace=True)
        self.dilated1 = nn.Sequential(*[DilatedBlock(64, 64) for i in range(1)])
        self.maxpool1 = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)  # 64*7*7
        self.conv2 = nn.Conv2d(in_channels=64, out_channels=128, kernel_size=3, stride=1, padding=1,
                               bias=True)  # 128*5*5
        self.bn2 = nn.BatchNorm2d(128)
        self.relu2 = nn.ReLU(inplace=True)
        self.dilated2 = nn.Sequential(*[DilatedBlock(128, 128) for i in range(1)])
        self.maxpool2 = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)  # 128*3*3
        # ECA
        self.layer3 = self._make_layer(128)  # 128*3*3
        # 对浅层SOC含量分布进行学习
        self.conv3 = nn.Conv2d(in_channels=1, out_channels=64, kernel_size=3, stride=1, padding=1, bias=True)  # 64*9*9
        # self.dilated3 = nn.Sequential(*[DilatedBlock(64, 64)])
        self.dilated3 = nn.Sequential(*[DilatedBlock(64, 64) for i in range(3)])
        self.conv4 = nn.Conv2d(in_channels=64, out_channels=128, kernel_size=3, stride=1, padding=0,
                               bias=True)  # 128*7*7
        self.maxpool3 = nn.MaxPool2d(kernel_size=3, stride=2)  # 128*3*3

        # 全连接层回归
        self.classifier = nn.Sequential(
            nn.Linear(in_features=2304, out_features=256, bias=True),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.5),
            nn.Linear(in_features=256, out_features=32, bias=True),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.5),
            nn.Linear(in_features=32, out_features=1, bias=True),
            # nn.Softmax(dim=-1)
        )

    def _make_layer(self, channel):
        # 定义一个空列表，用来装convx_x的网络结构
        layers = [ECA(channel)]
        # 首先要把第一个残差结构加进去，因为第一个残差结构涉及到虚线残差结构
        return nn.Sequential(*layers)

    def forward(self, input1, input2):
        x1 = self.conv1(input1)
        x1 = self.bn1(x1)
        x1 = self.relu1(x1)
        x1 = self.dilated1(x1)
        x1 = self.maxpool1(x1)
        x1 = self.conv2(x1)
        x1 = self.bn2(x1)
        x1 = self.relu2(x1)
        x1 = self.dilated2(x1)
        x1 = self.maxpool2(x1)
        x1 = self.layer3(x1)  # size 128*3*3
        # shallower SOC feature extraction wish output size 128*3*3
        x2 = self.conv3(input2)
        x2 = self.dilated3(x2)
        x2 = self.conv4(x2)
        x2 = self.maxpool3(x2)
        x = torch.cat([x1, x2], dim=1)
        # print('x1', x1.shape)
        # print('x2', x2.shape)
        # print('x', x.shape)
        x = torch.flatten(x, start_dim=1)
        # print('x', x.shape)
        x = self.classifier(x)
        # print('x', x.shape)
        return x


class Model5(nn.Module):
    """
    CBAM+one time dilated
    双输入（孪生网络）
    """

    def __init__(self):
        super(Model5, self).__init__()
        # 对特征进行学习
        # 30*9*9
        self.conv1 = nn.Conv2d(in_channels=30, out_channels=64, kernel_size=3, stride=1, padding=1, bias=True)
        # 64*9*9
        self.bn1 = nn.BatchNorm2d(64)
        self.relu1 = nn.ReLU(inplace=True)
        self.dilated1 = nn.Sequential(*[DilatedBlock(64, 64) for i in range(1)])
        self.maxpool1 = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)  # 64*7*7
        self.conv2 = nn.Conv2d(in_channels=64, out_channels=128, kernel_size=3, stride=1, padding=1,
                               bias=True)  # 128*5*5
        self.bn2 = nn.BatchNorm2d(128)
        self.relu2 = nn.ReLU(inplace=True)
        self.dilated2 = nn.Sequential(*[DilatedBlock(128, 128) for i in range(1)])
        self.maxpool2 = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)  # 128*3*3
        # ECA
        self.layer3 = self._make_layer(128)  # 128*3*3
        # 对浅层SOC含量分布进行学习
        self.conv3 = nn.Conv2d(in_channels=1, out_channels=64, kernel_size=3, stride=1, padding=1, bias=True)  # 64*9*9
        self.dilated3 = nn.Sequential(*[DilatedBlock(64, 64)])
        # self.dilated3 = nn.Sequential(*[DilatedBlock(64, 64) for i in range(3)])
        self.conv4 = nn.Conv2d(in_channels=64, out_channels=128, kernel_size=3, stride=1, padding=0,
                               bias=True)  # 128*7*7
        self.maxpool3 = nn.MaxPool2d(kernel_size=3, stride=2)  # 128*3*3

        # 全连接层回归
        self.classifier = nn.Sequential(
            nn.Linear(in_features=2304, out_features=256, bias=True),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.5),
            nn.Linear(in_features=256, out_features=32, bias=True),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.5),
            nn.Linear(in_features=32, out_features=1, bias=True),
            # nn.Softmax(dim=-1)
        )

    def _make_layer(self, channel):
        # 定义一个空列表，用来装convx_x的网络结构
        layers = [CBAM(channel)]
        # 首先要把第一个残差结构加进去，因为第一个残差结构涉及到虚线残差结构
        return nn.Sequential(*layers)

    def forward(self, input1, input2):
        x1 = self.conv1(input1)
        x1 = self.bn1(x1)
        x1 = self.relu1(x1)
        x1 = self.dilated1(x1)
        x1 = self.maxpool1(x1)
        x1 = self.conv2(x1)
        x1 = self.bn2(x1)
        x1 = self.relu2(x1)
        x1 = self.dilated2(x1)
        x1 = self.maxpool2(x1)
        x1 = self.layer3(x1)  # size 128*3*3
        # shallower SOC feature extraction wish output size 128*3*3
        x2 = self.conv3(input2)
        x2 = self.dilated3(x2)
        x2 = self.conv4(x2)
        x2 = self.maxpool3(x2)
        x = torch.cat([x1, x2], dim=1)
        # print('x1', x1.shape)
        # print('x2', x2.shape)
        # print('x', x.shape)
        x = torch.flatten(x, start_dim=1)
        # print('x', x.shape)
        x = self.classifier(x)
        # print('x', x.shape)
        return x


class Model6(nn.Module):
    """
    ECA+three times dilated
    双输入（孪生网络）
    """

    def __init__(self):
        super(Model6, self).__init__()
        # 对特征进行学习
        # 30*9*9
        self.conv1 = nn.Conv2d(in_channels=30, out_channels=64, kernel_size=3, stride=1, padding=1, bias=True)
        # 64*9*9
        self.bn1 = nn.BatchNorm2d(64)
        self.relu1 = nn.ReLU(inplace=True)
        self.dilated1 = nn.Sequential(*[DilatedBlock(64, 64) for i in range(1)])
        self.maxpool1 = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)  # 64*7*7
        self.conv2 = nn.Conv2d(in_channels=64, out_channels=128, kernel_size=3, stride=1, padding=1,
                               bias=True)  # 128*5*5
        self.bn2 = nn.BatchNorm2d(128)
        self.relu2 = nn.ReLU(inplace=True)
        self.dilated2 = nn.Sequential(*[DilatedBlock(128, 128) for i in range(1)])
        self.maxpool2 = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)  # 128*3*3
        # ECA
        self.layer3 = self._make_layer(128)  # 128*3*3
        # 对浅层SOC含量分布进行学习
        self.conv3 = nn.Conv2d(in_channels=1, out_channels=64, kernel_size=3, stride=1, padding=1, bias=True)  # 64*9*9
        # self.dilated3 = nn.Sequential(*[DilatedBlock(64, 64)])
        self.dilated3 = nn.Sequential(*[DilatedBlock(64, 64) for i in range(3)])
        self.conv4 = nn.Conv2d(in_channels=64, out_channels=128, kernel_size=3, stride=1, padding=0,
                               bias=True)  # 128*7*7
        self.maxpool3 = nn.MaxPool2d(kernel_size=3, stride=2)  # 128*3*3

        # 全连接层回归
        self.classifier = nn.Sequential(
            nn.Linear(in_features=2304, out_features=256, bias=True),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.5),
            nn.Linear(in_features=256, out_features=32, bias=True),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.5),
            nn.Linear(in_features=32, out_features=1, bias=True),
            # nn.Softmax(dim=-1)
        )

    def _make_layer(self, channel):
        # 定义一个空列表，用来装convx_x的网络结构
        layers = [CBAM(channel)]
        # 首先要把第一个残差结构加进去，因为第一个残差结构涉及到虚线残差结构
        return nn.Sequential(*layers)

    def forward(self, input1, input2):
        x1 = self.conv1(input1)
        x1 = self.bn1(x1)
        x1 = self.relu1(x1)
        x1 = self.dilated1(x1)
        x1 = self.maxpool1(x1)
        x1 = self.conv2(x1)
        x1 = self.bn2(x1)
        x1 = self.relu2(x1)
        x1 = self.dilated2(x1)
        x1 = self.maxpool2(x1)
        x1 = self.layer3(x1)  # size 128*3*3
        # shallower SOC feature extraction wish output size 128*3*3
        x2 = self.conv3(input2)
        x2 = self.dilated3(x2)
        x2 = self.conv4(x2)
        x2 = self.maxpool3(x2)
        x = torch.cat([x1, x2], dim=1)
        # print('x1', x1.shape)
        # print('x2', x2.shape)
        # print('x', x.shape)
        x = torch.flatten(x, start_dim=1)
        # print('x', x.shape)
        x = self.classifier(x)
        # print('x', x.shape)
        return x

# """print layers and params of network"""
# if __name__ == '__main__':
#     device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
#     model = Model2().to(device)
#     # print(model)
#     summary(model, [(30, 9, 9), (1, 9, 9)])
